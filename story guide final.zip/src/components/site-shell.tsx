import { Link } from '@tanstack/react-router';
import { useState } from 'react';
import { Menu, X, Instagram, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { contactEmail, instagramUrl } from '@/lib/contact';
import mark from '@/assets/storyguide-mark.webp.asset.json';

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const nav = <><Link to="/" activeOptions={{ exact: true }} activeProps={{ className: 'active' }}>Home</Link><Link to="/ebooks" search={{}} activeProps={{ className: 'active' }}>Ebooks</Link><Link to="/blog" activeProps={{ className: 'active' }}>Blog</Link><Link to="/about" activeProps={{ className: 'active' }}>About</Link><Link to="/contact" activeProps={{ className: 'active' }}>Contact</Link></>;
  return <header className="site-header editorial-container"><div className="masthead"><Link to="/" className="brand"><img src={mark.url} className="brand-mark" width={32} height={32} alt="" />StoryGuide<span>Reading Room</span></Link><nav className="desktop-nav" aria-label="Main navigation">{nav}</nav><Button variant="ghost" size="icon" className="menu-toggle" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button></div><p className="edition-label">The Publisher’s Desk <span>—</span> Stories, ideas & a little perspective</p>{open && <nav id="mobile-nav" className="mobile-nav" aria-label="Mobile navigation" onClick={() => setOpen(false)}>{nav}</nav>}</header>;
}
export function SiteFooter() {
  return <footer className="site-footer"><div className="editorial-container footer-inner"><Link to="/" className="brand">StoryGuide</Link><nav aria-label="Footer navigation"><Link to="/ebooks" search={{}}>Ebooks</Link><Link to="/blog">Blog</Link><Link to="/contact">Contact</Link></nav><div className="social-links"><Button variant="ghost" size="icon" asChild><a href={`mailto:${contactEmail}`} aria-label="Email StoryGuide" title="Email StoryGuide"><Mail strokeWidth={1.5} /></a></Button><Button variant="ghost" size="icon" asChild><a href={instagramUrl} target="_blank" rel="noopener noreferrer" aria-label="StoryGuide on Instagram" title="StoryGuide on Instagram"><Instagram strokeWidth={1.5} /></a></Button></div><p>© StoryGuide · A quiet reading room</p></div></footer>;
}